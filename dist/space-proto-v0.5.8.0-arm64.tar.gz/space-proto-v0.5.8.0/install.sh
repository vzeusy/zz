#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-999} -eq 0 ]] || { echo "Execute como root." >&2; exit 1; }
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nginx openssl ca-certificates curl openssh-server libpam-modules python3 sqlite3 iproute2 procps kmod util-linux iptables conntrack >/dev/null
case "$(uname -m)" in x86_64|amd64) ARCH=amd64;; aarch64|arm64) ARCH=arm64;; *) echo "Arquitetura não suportada: $(uname -m)" >&2; exit 1;; esac
BACKUP_DIR="/var/backups/space-proto/antes-v0.5.8.0-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BACKUP_DIR"
for p in /etc/space-proto /etc/nginx/conf.d/space-proto.conf /etc/systemd/system/space-proto.service /usr/local/bin/space-proto-server /usr/local/bin/space-udpgw /etc/systemd/system/space-udpgw.service /usr/local/sbin/spaceproto /usr/local/bin/spacectl /etc/sysctl.d/99-space-proto-smart-warm.conf /etc/pam.d/sshd /etc/nginx/nginx.conf /etc/systemd/system/spaceproto-user-enforcer.service /etc/systemd/system/spaceproto-user-enforcer.timer; do [[ -e "$p" ]] && cp -a "$p" "$BACKUP_DIR/" 2>/dev/null || true; done
systemctl stop space-proto.service >/dev/null 2>&1 || true
install -d -m 0755 /etc/space-proto/tls /usr/local/share/space-proto
id spaceproto >/dev/null 2>&1 || useradd --system --home /nonexistent --shell /usr/sbin/nologin spaceproto
install -m 0755 "$HERE/bin/space-proto-linux-$ARCH" /usr/local/bin/space-proto-server
install -m 0755 "$HERE/bin/space-udpgw-linux-$ARCH" /usr/local/bin/space-udpgw
install -m 0755 "$HERE/scripts/spaceproto-menu" /usr/local/sbin/spaceproto
install -m 0644 "$HERE/nginx/space-proto.conf.template" /usr/local/share/space-proto/space-proto.conf.template
install -m 0644 "$HERE/systemd/space-proto.service" /etc/systemd/system/space-proto.service
install -m 0644 "$HERE/systemd/space-udpgw.service" /etc/systemd/system/space-udpgw.service
install -m 0644 "$HERE/systemd/spaceproto-user-enforcer.service" /etc/systemd/system/spaceproto-user-enforcer.service
install -m 0644 "$HERE/systemd/spaceproto-user-enforcer.timer" /etc/systemd/system/spaceproto-user-enforcer.timer
install -d -m 0755 /usr/local/libexec /run/space-proto-online
install -m 0755 "$HERE/scripts/spaceproto-auth-track" /usr/local/libexec/spaceproto-auth-track
install -m 0755 "$HERE/scripts/spaceproto-online-snapshot" /usr/local/libexec/spaceproto-online-snapshot
install -m 0755 "$HERE/scripts/spaceproto-userdb" /usr/local/libexec/spaceproto-userdb
install -m 0755 "$HERE/scripts/spacectl" /usr/local/bin/spacectl
install -m 0755 "$HERE/scripts/spaceproto-network-recovery" /usr/local/libexec/spaceproto-network-recovery
install -m 0755 "$HERE/scripts/spaceproto-health-recovery" /usr/local/libexec/spaceproto-health-recovery
install -m 0644 "$HERE/systemd/spaceproto-network-recovery.service" /etc/systemd/system/spaceproto-network-recovery.service
install -m 0644 "$HERE/systemd/spaceproto-health-recovery.service" /etc/systemd/system/spaceproto-health-recovery.service
install -m 0644 "$HERE/systemd/spaceproto-health-recovery.timer" /etc/systemd/system/spaceproto-health-recovery.timer
chmod 0755 /run/space-proto-online

# usuarios.db is the single inventory/policy source for every SPACE user.
# Password hashes remain under Linux/OpenSSH (/etc/shadow); no plaintext password is stored in SQLite.
# If an older installation used /root/usuarios.db as the real SQLite database, adopt it when
# the canonical database does not exist yet, then make /root/usuarios.db a permanent symlink.
if [[ -e /root/usuarios.db && ! -L /root/usuarios.db ]]; then
  cp -a /root/usuarios.db "$BACKUP_DIR/usuarios.db.root-legacy" 2>/dev/null || true
  if [[ ! -s /etc/space-proto/usuarios.db ]] && sqlite3 /root/usuarios.db 'PRAGMA quick_check;' 2>/dev/null | grep -qx ok && sqlite3 /root/usuarios.db "SELECT 1 FROM sqlite_master WHERE type='table' AND name='usuarios';" 2>/dev/null | grep -qx 1; then
    cp -a /root/usuarios.db /etc/space-proto/usuarios.db
  fi
fi
/usr/local/libexec/spaceproto-userdb init >/dev/null
/usr/local/libexec/spaceproto-userdb import-linux >/dev/null || true
chown root:spaceproto /etc/space-proto/usuarios.db 2>/dev/null || true
chmod 0640 /etc/space-proto/usuarios.db 2>/dev/null || true
rm -f /root/usuarios.db 2>/dev/null || true
ln -s /etc/space-proto/usuarios.db /root/usuarios.db

# SPACE-local SSH sessions are authorized by usuarios.db at PAM account time.
# External administrative SSH is untouched: the hook ignores non-loopback RHOST.
# Any eligible Linux/OpenSSH account is imported into usuarios.db automatically; a local tunnel
# session without a usuarios.db record is rejected instead of being treated as unmanaged.
sed -i "\|account optional pam_exec.so quiet /usr/local/libexec/spaceproto-auth-track|d; \|account required pam_exec.so quiet /usr/local/libexec/spaceproto-auth-track|d; \|# SSHPRO SPACE PROTO authenticated-user tracker|d; \|# SSHPRO SPACE PROTO user policy|d" /etc/pam.d/sshd 2>/dev/null || true
PAM_LINE='account required pam_exec.so quiet /usr/local/libexec/spaceproto-auth-track'
printf '\n# SSHPRO SPACE PROTO user policy\n%s\n' "$PAM_LINE" >> /etc/pam.d/sshd

if [[ -s /etc/space-proto/config.json ]]; then
python3 - /etc/space-proto/config.json <<'PY'
import json,sys
p=sys.argv[1]
try: c=json.load(open(p))
except: c={}
c.update({'listen':'127.0.0.1:18080','target_host':'127.0.0.1','target_port':22,'xhttp_enabled':True,'xhttp_paths':['/','/space-proto','/ssh-xhttp','/xhttp'],'xhttp_any_path':True,'bhttp_raw_listen':'127.0.0.1:18082','bhttp_mux_listen':'0.0.0.0:80','http_fallback':'127.0.0.1:18081','bhttp_tls_mux_listen':'0.0.0.0:443','tls_fallback':'127.0.0.1:18443','session_idle_seconds':1800,'dial_timeout_seconds':1,'udpgw_port':7300,'transport_grace_seconds':300,'min_hot_download_lanes':4,'tcp_keepalive_seconds':15,'tcp_user_timeout_seconds':30,'auth_priority_seconds':2,'auth_priority_upload_bytes':1024,'connecting_timeout_seconds':20})
json.dump(c,open(p,'w'),indent=2); open(p,'a').write('\n')
PY
else
  install -m 0640 "$HERE/examples/config.json" /etc/space-proto/config.json
fi
chown root:spaceproto /etc/space-proto/config.json; chmod 0640 /etc/space-proto/config.json

# Perfil de rede MAX-SPEED/STABLE com autotuning ampliado. Os limites abaixo são tetos de autotuning,
# não reservas por conexão: o kernel só usa memória quando há tráfego real.
# Os valores são tetos de autotuning; BBR+fq continua responsável por pacing quando suportado.
cat > /etc/sysctl.d/99-space-proto-smart-warm.conf <<'SYSCTL'
net.core.somaxconn=32768
net.core.netdev_max_backlog=32768
net.core.rmem_max=67108864
net.core.wmem_max=67108864
net.ipv4.tcp_rmem=4096 262144 67108864
net.ipv4.tcp_wmem=4096 262144 67108864
net.ipv4.tcp_max_syn_backlog=32768
net.ipv4.tcp_keepalive_time=30
net.ipv4.tcp_keepalive_intvl=10
net.ipv4.tcp_keepalive_probes=3
net.ipv4.tcp_mtu_probing=1
net.ipv4.tcp_slow_start_after_idle=0
net.ipv4.tcp_window_scaling=1
net.ipv4.tcp_moderate_rcvbuf=1
net.ipv4.tcp_fastopen=3
SYSCTL
modprobe sch_fq >/dev/null 2>&1 || true
modprobe tcp_bbr >/dev/null 2>&1 || true
if sysctl -n net.ipv4.tcp_available_congestion_control 2>/dev/null | grep -qw bbr; then
  cat >> /etc/sysctl.d/99-space-proto-smart-warm.conf <<'SYSCTL'
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
SYSCTL
fi
sysctl --system >/dev/null 2>&1 || true

cat >/etc/space-proto/ports.env <<'PORTS'
HTTP_PORT=80
BHTTP_PORT=18082
HTTPS_PORT=443
TLS_BACKEND_PORT=18443
SPACE_PATH=/space-proto
PORTS
source /etc/space-proto/ports.env
HTTP_PORT=80; BHTTP_PORT=18082; HTTPS_PORT=443; TLS_BACKEND_PORT=18443

if [[ ! -s /etc/space-proto/tls/origin.key || ! -s /etc/space-proto/tls/origin.crt ]]; then
  openssl req -x509 -newkey rsa:3072 -sha256 -nodes -days 3650 -subj '/CN=space-proto-origin' -keyout /etc/space-proto/tls/origin.key -out /etc/space-proto/tls/origin.crt >/dev/null 2>&1
fi
# The Go service runs as User=spaceproto and terminates TLS for direct-IP BHTTP on 443.
# Keep the private key non-world-readable, but grant the service group read access.
chown root:spaceproto /etc/space-proto/tls/origin.key /etc/space-proto/tls/origin.crt
chmod 0640 /etc/space-proto/tls/origin.key
chmod 0644 /etc/space-proto/tls/origin.crt
if ! runuser -u spaceproto -- test -r /etc/space-proto/tls/origin.key; then
  echo "❌ spaceproto não consegue ler /etc/space-proto/tls/origin.key" >&2
  exit 1
fi
sed -e "s/__HTTP_PORT__/${HTTP_PORT}/g" -e "s/__BHTTP_PORT__/${BHTTP_PORT}/g" -e "s/__HTTPS_PORT__/${HTTPS_PORT}/g" -e "s/__TLS_BACKEND_PORT__/${TLS_BACKEND_PORT}/g" "$HERE/nginx/space-proto.conf.template" > /etc/nginx/conf.d/space-proto.conf
rm -f /etc/nginx/sites-enabled/default
# Ubuntu 20 ships a conservative worker_connections value. Raising the ceiling
# does not consume connections by itself and prevents hot XHTTP lanes from
# hitting the worker cap as more users connect.
sed -ri 's/^[[:space:]]*worker_connections[[:space:]]+[0-9]+;/    worker_connections 16384;/' /etc/nginx/nginx.conf 2>/dev/null || true
nginx -t

# Restore the real external path before starting listeners. This removes only
# stale 80/443 REDIRECT/DNAT/TPROXY rules; it never flushes the host firewall.
/usr/local/libexec/spaceproto-network-recovery

systemctl daemon-reload
/usr/sbin/sshd -t
systemctl enable --now ssh >/dev/null 2>&1 || systemctl enable --now sshd >/dev/null 2>&1 || true
# Reload picks up the PAM tracker for new logins without terminating existing SSH sessions.
systemctl reload ssh >/dev/null 2>&1 || systemctl reload sshd >/dev/null 2>&1 || true
systemctl enable nginx spaceproto-network-recovery.service space-proto space-udpgw spaceproto-user-enforcer.timer spaceproto-health-recovery.timer >/dev/null
systemctl restart spaceproto-network-recovery.service
systemctl restart nginx
sleep .3
systemctl restart space-proto space-udpgw
systemctl start spaceproto-user-enforcer.timer spaceproto-health-recovery.timer >/dev/null 2>&1 || true
sleep 1
if ! systemctl is-active --quiet space-proto; then
  echo "❌ space-proto.service não iniciou. Últimas linhas do journal:" >&2
  journalctl -u space-proto.service -n 30 --no-pager >&2 || true
  exit 1
fi
echo "✅ space-proto.service ativo; chave TLS legível pelo usuário spaceproto"

fail=0
if /usr/local/libexec/spaceproto-userdb list >/dev/null 2>&1 && sqlite3 /etc/space-proto/usuarios.db 'PRAGMA integrity_check;' 2>/dev/null | grep -qx ok; then
  echo "✅ usuarios.db íntegro em /etc/space-proto/usuarios.db"
else
  echo "❌ usuarios.db inválido"
  fail=1
fi
check_listener(){ local port=$1 label=$2; if ss -ltnH | awk '{print $4}' | grep -qE "(^|:)$port$"; then echo "✅ $label porta $port escutando"; else echo "❌ $label porta $port NÃO está escutando"; fail=1; fi; }
check_listener 22 OpenSSH
check_listener "$HTTP_PORT" HTTP
check_listener "$BHTTP_PORT" "BHTTP-RAW-INTERNO"
check_listener "$HTTPS_PORT" HTTPS
check_listener 7300 UDPGW

HCODE=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 "http://127.0.0.1:${HTTP_PORT}/healthz" || true)
[[ "$HCODE" == 200 ]] || { echo "❌ healthcheck HTTP=$HCODE"; fail=1; }

# DTunnel 5 native SSH_BHTTP RAW self-test on 8080 and smart-mux 80.
if python3 "$HERE/scripts/bhttp-selftest.py" "$BHTTP_PORT" "$HTTP_PORT" "$HTTPS_PORT"; then
  echo "✅ SSH_BHTTP nativo validado; público=${HTTP_PORT}, raw-interno=${BHTTP_PORT}; XHTTP/TLS=${HTTPS_PORT}"
else
  echo "❌ SSH_BHTTP nativo self-test falhou"
  fail=1
fi

# Direct HTTPS must negotiate HTTP/2. DTunnel Lite 4.6.5 explicitly rejects
# SSH_XHTTP download responses that are not HTTP/2.
H2INFO=$(curl -ksS --http2 --resolve "space-proto-selftest.invalid:${HTTPS_PORT}:127.0.0.1" -o /dev/null -w '%{http_version} %{http_code}' --max-time 3 "https://space-proto-selftest.invalid:${HTTPS_PORT}/healthz" || true)
H2VER=${H2INFO%% *}; H2CODE=${H2INFO##* }
if [[ "$H2VER" == "2" && "$H2CODE" == "200" ]]; then
  echo "✅ HTTPS porta ${HTTPS_PORT} negocia HTTP/2"
else
  echo "❌ HTTPS/HTTP2 esperado '2 200', veio '${H2INFO:-sem resposta}'"
  fail=1
fi

# Ordinary probes must remain 400; they must not consume an SSH session.
PCODE=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 2 "http://127.0.0.1:${HTTP_PORT}/" || true)
[[ "$PCODE" == 400 ]] || { echo "❌ Probe HTTP esperado 400, veio $PCODE"; fail=1; }

# Reproduce the exact native DTunnel Lite 4.6.5 download surface:
# POST + x-http-sid + x-http-mode=download + frame format.
rm -f /tmp/space-native-xhttp-frame.bin
XCODE=$(curl -sS -N -o /tmp/space-native-xhttp-frame.bin -w '%{http_code}' --max-time 1 \
  -X POST \
  -H 'Host: install-test.invalid' \
  -H 'x-http-sid: space-install-selftest' \
  -H 'x-http-mode: download' \
  -H 'x-http-download-format: frame' \
  -H 'Accept: text/event-stream' \
  -H 'Accept-Encoding: identity' \
  "http://127.0.0.1:${HTTP_PORT}/" 2>/dev/null || true)
[[ "$XCODE" == 200 ]] || { echo "❌ Native XHTTP download esperado 200, veio ${XCODE:-sem resposta}"; fail=1; }
if python3 - /tmp/space-native-xhttp-frame.bin <<'PY'
import struct,sys
b=open(sys.argv[1],'rb').read()
assert b.startswith(b':\r\n\r\n'), 'prefixo ausente'
assert len(b) >= 17, 'frame incompleto'
seq=struct.unpack('>Q',b[5:13])[0]
ln=struct.unpack('>I',b[13:17])[0]
assert seq == 0, seq
assert 0 < ln <= 1048576, ln
assert len(b) >= 17+ln, (len(b),ln)
p=b[17:17+ln]
assert p.startswith(b'SSH-2.0-'), p[:32]
print('✅ Frame nativo DTunnel: prefix + seq=0 + tamanho + banner SSH OK')
PY
then :; else echo "❌ Estrutura de frame DTunnel inválida"; fail=1; fi
rm -f /tmp/space-native-xhttp-frame.bin

# Clear the temporary self-test SSH session before real clients connect.
systemctl restart space-proto
sleep .5
/usr/local/libexec/spaceproto-network-recovery >/dev/null 2>&1 || true

# Final listener guard after every restart.
for p in 80 443; do
  if ! ss -ltnH | awk '{print $4}' | grep -qE "(^|:)$p$"; then
    echo "❌ Porta pública $p não voltou após restart" >&2
    fail=1
  fi
done

if ((fail)); then
  echo "Falha de validação. Backup: $BACKUP_DIR" >&2
  exit 1
fi

echo "✅ SSHPRO SPACE PROTO v0.5.8.0 DTUNNEL 5 NATIVE BHTTP RAW + USUARIOS.DB instalado"
echo "✅ DTunnel Lite 4.6.5 SSH_XHTTP NATIVO preservado"
echo "✅ SSH_BHTTP binário nativo disponível por IP direto na porta ${HTTP_PORT}; XHTTP/TLS em ${HTTPS_PORT}"
echo "✅ DTunnel/NET SPACE PRO 5.0: BHTTP público 80 + XHTTP/TLS 443; RAW de diagnóstico somente em 127.0.0.1:18082"
echo "✅ Download = POST + x-http-mode: download + x-http-sid"
echo "✅ Upload = POST + x-http-mode: upload + x-http-seq"
echo "✅ Download frame = :\\r\\n\\r\\n + uint64(seq) + uint32(len) + payload"
echo "✅ Conexão rápida v2: banner na lane primária e liberação das hot lanes no primeiro upload SSH"
echo "✅ usuarios.db FONTE ÚNICA: /etc/space-proto/usuarios.db (atalho /root/usuarios.db)"
echo "✅ OpenSSH continua autenticando senhas; banco controla validade, status e limite de conexões"
echo "✅ Usuários Linux existentes foram sincronizados sem vencimento/limite para preservar compatibilidade"
echo "✅ Usuário ONLINE registrado pelo PAM/OpenSSH real e enriquecido pelo usuarios.db"
echo "✅ Menu [07] sem piscar: redesenha somente ao conectar/desconectar usuário; mostra usuário e horário real de autenticação"
echo "✅ Streams XHTTP paralelos mantidos como HOT LANES (alvo: 4+)"
echo "✅ Queda de uma lane não derruba a sessão SSH; lanes restantes continuam ativas"
echo "✅ Sessão preservada por até 180s para reanexar lanes com o mesmo x-http-sid"
echo "✅ MAX-SPEED: TCP_NODELAY, buffers autotuning até 64 MiB, BBR+fq quando suportados e BHTTP com batching/prefetch ampliado"
echo "✅ Handshakes XHTTP abandonados são limpos em 20s para não acumular CONECTANDO/hot lanes"
echo "✅ Porta 443 TLS-aware mux: BHTTP RAW, BHTTP sobre TLS por IP direto, ou HTTPS/XHTTP com SNI + HTTP/2"
echo "✅ BHTTP/${HTTP_PORT} + BHTTP+HTTPS-XHTTP/${HTTPS_PORT} + BHTTP/${BHTTP_PORT} + OpenSSH 22 + UDPGW 7300 verificados"
echo "➡️ Menu: spaceproto | usuários: spaceproto users | banco: spaceproto db list"
echo "💾 Backup: $BACKUP_DIR"

echo "✅ NETWORK-RESTORE: redirects NAT/TPROXY antigos de 80/443 removidos sem flush global"
echo "✅ Público: BHTTP :80 | XHTTP/TLS :443 | RAW interno 127.0.0.1:18082"
